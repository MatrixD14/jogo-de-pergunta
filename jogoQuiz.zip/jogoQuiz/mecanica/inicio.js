
  var form= document.querySelector('#nomeForm');
  var buto = document.querySelector('#but');
  var nome = document.querySelector('#Nome');
  var mens = document.querySelector('#menssagem');
function test(){
  window.location.href="jogo.html";
}
