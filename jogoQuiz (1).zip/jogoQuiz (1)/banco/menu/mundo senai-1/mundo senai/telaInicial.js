document.getElementById('startButton').addEventListener('click', function() {
    window.location.href = 'game.html';
});